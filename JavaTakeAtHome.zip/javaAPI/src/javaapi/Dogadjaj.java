/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package javaapi;

/**
 *
 * @author FON
 */
public class Dogadjaj {
    private Grad grad;
    private String nazivDogadjaja;
    private String opis;

    public Dogadjaj() {
    }

    public Dogadjaj(Grad grad, String nazivDogadjaja, String opis) {
        this.grad = grad;
        this.nazivDogadjaja = nazivDogadjaja;
        this.opis = opis;
    }
    

    public Dogadjaj(Grad grad, String nazivDogadjaja) {
        this.grad = grad;
        this.nazivDogadjaja = nazivDogadjaja;
    }

    public String getNazivDogadjaja() {
        return nazivDogadjaja;
    }

    public void setNazivDogadjaja(String nazivDogadjaja) {
        this.nazivDogadjaja = nazivDogadjaja;
    }

    public Grad getGrad() {
        return grad;
    }

    public void setGrad(Grad grad) {
        this.grad = grad;
    }

    public String getOpis() {
        return opis;
    }

    public void setOpis(String opis) {
        this.opis = opis;
    }

    @Override
    public String toString() {
        return "Dogadjaj : "+nazivDogadjaja+" ce se odrzati u gradu : "+getGrad().getNaziv()+ ". Kratak opis dogadjaja: "+opis; 
    }
    
    
}
