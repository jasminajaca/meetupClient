/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package javaapi;

/**
 *
 * @author FON
 */
public class Grad {
    private int redniBroj;
    private String naziv;

    public Grad() {
    }
    
    public Grad(String naziv){
        this.naziv = naziv;
    }

    public Grad(int redniBroj, String naziv) {
        this.redniBroj = redniBroj;
        this.naziv = naziv;
    }

    public int getRedniBroj() {
        return redniBroj;
    }

    public void setRedniBroj(int redniBroj) {
        this.redniBroj = redniBroj;
    }

    public String getNaziv() {
        return naziv;
    }

    public void setNaziv(String naziv) {
        this.naziv = naziv;
    }
    
    
    
}
