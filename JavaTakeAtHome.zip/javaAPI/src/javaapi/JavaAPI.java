/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package javaapi;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.net.URL;
import java.util.LinkedList;
import java.util.logging.Level;
import java.util.logging.Logger;
import org.json.JSONException;
import org.json.JSONObject;
import org.json.JSONArray;

/**
 *
 * @author FON
 */
public class JavaAPI {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        LinkedList<Grad> gradovi = new LinkedList<>();
        LinkedList<Dogadjaj> dogadjaji = new LinkedList<Dogadjaj>();
        
        
        try {
           URL url1 = new URL("https://api.meetup.com/2/cities?country=rs&offset=0&format=json&photo-host=public&page=20&radius=50&order=size&desc=false&sig_id=263783401&sig=e44f6f933bd2cb80331d18d02c26b02499049054");
           URL url = new URL("https://api.meetup.com/2/concierge?country=rs&offset=0&format=json&photo-host=public&page=500&sig_id=263783401&sig=35ec6956bb19112e0d48f16b28875b73f72ef02b");
           HttpURLConnection conn = (HttpURLConnection) url1.openConnection();
           conn.setRequestMethod("GET");
           
           if (conn.getResponseCode() != 200) {
		throw new RuntimeException("Neuspesno : HTTP error code : " + conn.getResponseCode());
		}

		
           BufferedReader br = new BufferedReader(new InputStreamReader((conn.getInputStream())));
           StringBuilder sb = new StringBuilder();
           String line;
		
		while((line = br.readLine())!= null){
			sb.append(line);
                }
              JSONObject rezultat = new JSONObject(sb.toString());
              JSONArray niz = rezultat.getJSONArray("results");
              
              int rb = 0;
              for (int i = 0; i < niz.length(); i++) {
              JSONObject GRAD = niz.getJSONObject(i);
              String naziv = GRAD.getString("city");
              rb = rb +1;
              Grad novi = new Grad(rb, naziv);
              gradovi.add(novi);
              System.out.println(" Rbr: "+rb+" Naziv: "+naziv);
              }
              conn.disconnect();
              
              BufferedReader brr = new BufferedReader(new InputStreamReader(System.in));
              System.out.println("Upisite redni broj onog grada za koga zalite spisak dogadjaja: ");
              int unos=0;
              try{
                unos = Integer.parseInt(brr.readLine());
                }catch(NumberFormatException nfe){
                    System.err.println("Morate uneti broj!");
                }
              String naziv = "";
              for (Grad g : gradovi) {
                if(g.getRedniBroj()==unos){
                    naziv = g.getNaziv();
                }
            }
              if(naziv.equals("")){
                  return;
              }
              
              HttpURLConnection conn2 = (HttpURLConnection) url.openConnection();
              conn2.setRequestMethod("GET");
           
           if (conn2.getResponseCode() != 200) {
		throw new RuntimeException("Neuspesno : HTTP error code : " + conn2.getResponseCode());
		}
           
           
           BufferedReader br2 = new BufferedReader(new InputStreamReader((conn2.getInputStream())));
           StringBuilder sb2 = new StringBuilder();
           String linija;
		
		while((linija = br2.readLine())!= null){
			sb2.append(linija);
                }
              JSONObject rezultat2 = new JSONObject(sb2.toString());
              JSONArray niz2 = rezultat2.getJSONArray("results");
              
              
              for (int i = 0; i < niz.length(); i++) {
              JSONObject dogadjaj = niz2.getJSONObject(i);
              JSONObject venue = dogadjaj.getJSONObject("venue");
              String nazivGr = venue.getString("city");
              String nazivDogadjaja = dogadjaj.getString("name");
              String opis = dogadjaj.getString("description");
              Grad g = new Grad(nazivGr);
              Dogadjaj d = new Dogadjaj(g, nazivDogadjaja, opis);
              dogadjaji.add(d);
              }
              boolean postoji = false;
              for (Dogadjaj dog : dogadjaji) {
                if(dog.getGrad().getNaziv().equals(naziv)){
    
                    System.out.println(dog);
                    postoji = true;
                }
            }
              if(postoji == false ){
                  System.out.println("Ne postoji dogadjaj u izabranom gradu");
              }
           
              
              
              conn2.disconnect();

              
        } catch (MalformedURLException ex) {
            Logger.getLogger(JavaAPI.class.getName()).log(Level.SEVERE, null, ex);
        } catch (IOException ex) {
            Logger.getLogger(JavaAPI.class.getName()).log(Level.SEVERE, null, ex);
        }
		
       catch (JSONException ex) {
            Logger.getLogger(JavaAPI.class.getName()).log(Level.SEVERE, null, ex);
        } 
    
}
}